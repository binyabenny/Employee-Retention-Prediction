import pandas as pd
import pickle
from xgboost import XGBClassifier

# 1. Load your dataset (Using the correct filename found in your folder)
try:
    df = pd.read_csv("aug_train.csv")
    print("✅ Dataset loaded successfully.")
except FileNotFoundError:
    print("❌ Error: 'aug_train.csv' not found. Please check the filename.")
    exit()

# 2. Separate Features and Target
# Dropping 'enrollee_id' if it exists as it's not a predictor
if 'enrollee_id' in df.columns:
    df = df.drop(columns=['enrollee_id'])

X = df.drop("target", axis=1)
y = df["target"]

# 3. Preprocessing: Convert text to numbers (One-Hot Encoding)
X = pd.get_dummies(X)

# 4. Clean column names for XGBoost compatibility
X.columns = X.columns.astype(str).str.replace(r"[<>\[\]]", "_", regex=True)

# 5. Save the list of feature columns
# This is critical so the App knows the exact order of data
with open("columns.pkl", "wb") as f:
    pickle.dump(X.columns.tolist(), f)

# 6. Train the XGBoost Model
model = XGBClassifier(
    n_estimators=200,
    max_depth=5,
    learning_rate=0.1,
    eval_metric="logloss",
    random_state=42
)
model.fit(X.values, y.values)

# 7. Save the trained model
with open("model.pkl", "wb") as f:
    pickle.dump(model, f)

print("✅ SUCCESS: model.pkl and columns.pkl are now ready in your folder.")