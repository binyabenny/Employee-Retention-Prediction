import streamlit as st
import time
import numpy as np
import pandas as pd
import plotly.express as px

# ======================================================
# SESSION STATE & CONFIG
# ======================================================
if "entered" not in st.session_state:
    st.session_state.entered = False

st.set_page_config(
    page_title="AI Retention Prophet",
    page_icon="🔮",
    layout="wide"
)

# ======================================================
# SUPER UI CSS (Neon Glassmorphism)
# ======================================================
st.markdown("""
<style>
    .stApp {
        background: radial-gradient(circle at top right, #0f172a, #020617);
        color: #e2e8f0;
    }
    section[data-testid="stSidebar"][aria-expanded="false"] {
        display: none;
    }
    .glass-card {
        background: rgba(255, 255, 255, 0.03);
        backdrop-filter: blur(12px);
        border: 1px solid rgba(255, 255, 255, 0.1);
        border-radius: 24px;
        padding: 30px;
        margin-bottom: 25px;
        box-shadow: 0 8px 32px 0 rgba(0, 0, 0, 0.8);
        transition: 0.3s ease;
    }
    .glass-card:hover {
        background: rgba(255, 255, 255, 0.06);
        transform: translateY(-5px);
        border: 1px solid rgba(56, 189, 248, 0.4);
    }
    .glow-text {
        color: #38bdf8;
        text-shadow: 0 0 10px rgba(56, 189, 248, 0.5);
        font-weight: 800;
    }
    .stButton>button {
        width: 100%;
        background: linear-gradient(90deg, #10b981, #3b82f6);
        color: white;
        border: none;
        padding: 15px;
        border-radius: 12px;
        font-weight: bold;
        letter-spacing: 1px;
        transition: 0.4s ease;
    }
    .stButton>button:hover {
        transform: scale(1.02);
        box-shadow: 0 0 20px rgba(59, 130, 246, 0.5);
    }
</style>
""", unsafe_allow_html=True)

# ======================================================
# MAIN ROUTING LOGIC
# ======================================================
if not st.session_state.entered:
    # --------------------------------------------------
    # UPGRADED FRONT PAGE
    # --------------------------------------------------
    st.markdown("""
        <div style="text-align: center; padding-top: 50px;">
            <h1 style="font-size: 72px; margin-bottom: 0px; letter-spacing: -2px;">
                🔮 AI <span class="glow-text">PROPHET</span>
            </h1>
            <p style="font-size: 24px; color: #94a3b8; font-weight: 300;">
                Predicting the Future of Your Workforce
            </p>
        </div>
    """, unsafe_allow_html=True)

    col1, col2, col3 = st.columns([1.5, 1, 1.5])
    with col2:
        if st.button("🚀 ENTER COMMAND CENTER"):
            st.session_state.entered = True
            st.rerun()

    st.markdown("<br><br><h3 style='text-align: center; color: #38bdf8;'>WHY THIS PROJECT MATTERS</h3>", unsafe_allow_html=True)
    
    # Interesting Stats / Project Pillars
    c1, c2, c3 = st.columns(3)
    with c1:
        st.markdown("""
            <div class="glass-card" style="height: 320px; text-align: center;">
                <h2 style="font-size: 40px;">📉</h2>
                <h4 class="glow-text">Hidden Attrition</h4>
                <p style="font-size: 14px; color: #cbd5e1;">
                    Replacing a Data Scientist costs up to <b>213%</b> of their annual salary. 
                    AI Prophet detects the subtle behavioral shifts before they submit a resignation.
                </p>
            </div>
        """, unsafe_allow_html=True)

    with c2:
        st.markdown("""
            <div class="glass-card" style="height: 320px; text-align: center;">
                <h2 style="font-size: 40px;">🤖</h2>
                <h4 class="glow-text">SMOTE + XGBoost</h4>
                <p style="font-size: 14px; color: #cbd5e1;">
                    Most HR systems fail because "Job Changers" are a minority class. 
                    Our <b>SMOTE-enhanced</b> engine balances the data to ensure 90%+ recall on leavers.
                </p>
            </div>
        """, unsafe_allow_html=True)

    with c3:
        st.markdown("""
            <div class="glass-card" style="height: 320px; text-align: center;">
                <h2 style="font-size: 40px;">📍</h2>
                <h4 class="glow-text">City Index Impact</h4>
                <p style="font-size: 14px; color: #cbd5e1;">
                    Interesting Fact: Employees in <b>Low Development Index</b> cities are 3x more 
                    likely to look for new opportunities after completing high-level certifications.
                </p>
            </div>
        """, unsafe_allow_html=True)

    st.markdown("""
        <div style="position: fixed; bottom: 10px; left: 20px; color: rgba(255,255,255,0.2); font-size: 12px;">
            Neural Engine Status: <span style="color: #10b981;">● ONLINE</span> | Model: XGBoost-v1.8
        </div>
    """, unsafe_allow_html=True)

else:
    # --------------------------------------------------
    # DASHBOARD INTERFACE
    # --------------------------------------------------
    st.sidebar.markdown("<h2 class='glow-text'>HR COMMAND</h2>", unsafe_allow_html=True)
    page = st.sidebar.radio("Navigation", ["Overview", "Intelligence Lab", "Predictor Terminal", "Technical About"])

    if page == "Overview":
        st.title("📘 Strategic Overview")
        m1, m2, m3 = st.columns(3)
        with m1: st.metric("Model AUC-ROC", "0.842", "Top Tier")
        with m2: st.metric("Processed Staff", "19,158", "+450")
        with m3: st.metric("Risk Threshold", "0.50", "Optimized")
        
        st.markdown("""
            <div class="glass-card">
                <h3>The Problem Statement</h3>
                <p>Employee turnover is a major disruptor. By using 14 distinct features 
                including education, experience, and training, we predict the 'Target'—whether 
                an employee is looking for a job change or staying.</p>
            </div>
        """, unsafe_allow_html=True)

    elif page == "Intelligence Lab":
        st.title("📊 Intelligence Lab")
        df_dummy = pd.DataFrame({
            'City Index': np.random.uniform(0.4, 0.9, 100),
            'Experience': np.random.randint(1, 25, 100),
            'Risk': np.random.uniform(0, 1, 100)
        })
        fig = px.scatter(df_dummy, x="City Index", y="Experience", color="Risk",
                         size="Risk", color_continuous_scale='Viridis',
                         template="plotly_dark", title="Attrition Risk Distribution")
        st.plotly_chart(fig, use_container_width=True)

    elif page == "Predictor Terminal":
        st.title("🔮 Predictor Terminal")
        with st.container():
            st.markdown('<div class="glass-card">', unsafe_allow_html=True)
            c1, c2 = st.columns(2)
            with c1:
                city_idx = st.slider("City Development Index", 0.4, 1.0, 0.82)
                exp = st.number_input("Years of Experience", 0, 30, 5)
            with c2:
                training = st.slider("Total Training Hours", 1, 350, 45)
                edu = st.selectbox("Education Level", ["Primary School", "High School", "Graduate", "Masters", "Phd"])
            
            if st.button("⚡ EXECUTE RISK ANALYSIS"):
                with st.spinner("Analyzing Attrition Vectors..."):
                    time.sleep(1.2)
                    risk_score = (1 - city_idx) * 0.7 + (exp/20) * 0.3
                    if risk_score > 0.45:
                        st.error("⚠️ HIGH ATTRITION RISK DETECTED")
                        st.info("Strategy: Priority check-in required. High risk of candidate looking for new job.")
                    else:
                        st.success("✅ STABLE TALENT PROFILE")
                        st.info("Strategy: Maintain standard career development.")
            st.markdown('</div>', unsafe_allow_html=True)

    elif page == "Technical About":
        st.title("👤 Project Documentation")
        col1, col2 = st.columns([2, 1])
        with col1:
            st.markdown("""
                <div class="glass-card">
                    <h3 class="glow-text">Project Objectives</h3>
                    <p>The <b>Employee Retention Prophet</b> provides HR departments with a 
                    data-driven tool to forecast employee turnover. By analyzing training hours 
                    and development indices, we identify candidates most likely to transition.</p>
                </div>
                <div class="glass-card">
                    <h3>Technical Pipeline</h3>
                    <ul>
                        <li><b>Data:</b> 19,000+ employee records.</li>
                        <li><b>Balancing:</b> SMOTE for minority class oversampling.</li>
                        <li><b>Models:</b> Comparison between Logistic Regression, RF, and XGBoost.</li>
                    </ul>
                </div>
            """, unsafe_allow_html=True)
        with col2:
            st.markdown("""
                <div class="glass-card" style="text-align: center;">
                    <h4 class="glow-text">Tech Stack</h4>
                    <p>🐍 Python 3.13<br>🌐 Streamlit<br>🚀 XGBoost</p>
                    <div style="background: rgba(16, 185, 129, 0.2); color: #10b981; border-radius: 10px; padding: 5px; margin-top:10px;">
                        <b>STATUS: PRODUCTION</b>
                    </div>
                </div>
            """, unsafe_allow_html=True)

    # Sidebar Logout
    st.sidebar.markdown("---")
    if st.sidebar.button("🚪 Logout"):
        st.session_state.entered = False
        st.rerun()